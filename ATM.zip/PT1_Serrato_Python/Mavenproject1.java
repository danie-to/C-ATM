/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.mavenproject1;

import java.util.Scanner;

/**
 *
 * @author admin
 */
public class Mavenproject1 {

    public static void main(String[] args) {
        String registerUsername = " ";
        String registerPassword = " ";
        String loginUsername;
        String loginPassword;
        float balance, withdraw, deposit;
        balance = 0;
        
        boolean programIsRunning = true;
 
        while (programIsRunning) {
        Scanner scn = new Scanner(System.in);
        System.out.println("===== Hi! :D Welcome to the Meep ATM Machine! =====\n");
        System.out.println("Please select an option from the menu below:");
        System.out.println("[1] Login\n[2] Register\n[3] Quit");
        int option = scn.nextInt();
        
        switch(option)
        {
            case 1:
                System.out.println("===== LOGIN =====");
                
                System.out.print("Enter username: ");
                scn.nextLine();
                loginUsername = scn.nextLine();
                System.out.print("Enter password: ");
                loginPassword = scn.nextLine();
                
                if (loginUsername.equals(registerUsername) && loginPassword.equals(registerPassword)) {
                System.out.println("");
                System.out.println("Successfully logged in!\n");
                } else {
                    System.out.println("Incorrect username or password! :( Please try again after the program restarts!");
                    System.exit(0);
                }
                System.out.println("What would you like to do?\n");
                System.out.println("[1] Deposit\n[2] Withdraw\n[3] View Balance\n[4] Menu\n");
                int choice = scn.nextInt();
                
                while (choice!= 4) {
                switch(choice)
                {
                    case 1:
                        System.out.println("===== DEPOSIT =====");
                        
                        System.out.println("Amount of deposit: ");
                        deposit = scn.nextFloat();
                        balance = balance + deposit;
                        
                        System.out.println("");
                        System.out.println("Successfully deposited!");
                        break;
                    
                    case 2:
                        System.out.println("===== WITHDRAW =====");
                        
                        System.out.println("Amount of withdrawal: ");
                        withdraw = scn.nextFloat();
                        balance = balance - withdraw;
                        
                        System.out.println("");
                        System.out.println("Successfully withdrawn!");
                        break;
                        
                    case 3:
                        System.out.println("===== BALANCE =====");
                        
                        System.out.println("Balance: "+balance);
                        
                        System.out.println("");
                        break;
                        
                    case 4:
                        break;
                        
                    default:
                        System.out.println("\nInvalid input. Try again!\n");
                        break;
                        }
                    System.out.println("[1] Deposit\n[2] Withdraw\n[3] View Balance\n[4] Menu\n");
                    choice = scn.nextInt();
                }
                break;
            
            case 2:
                System.out.println("===== REGISTER =====");
                
                System.out.print("Enter username: ");
                scn.nextLine();
                registerUsername = scn.nextLine();
                
                System.out.print("Enter password: ");
                registerPassword = scn.nextLine();
                
                System.out.println("Account successfully registered!");
                
                System.out.println("");
                break;
            
            case 3:
                System.out.println("Thank you for using our ATM! Come again soon!");
                System.exit(0);
                break;
            default:
                System.out.println("\nInvalid input. Try again!\n");
                break;
        }
               
        }
    }
}
